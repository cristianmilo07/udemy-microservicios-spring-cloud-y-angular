package com.formacionbdi.microservicios.commos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonsMicroserviciosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonsMicroserviciosApplication.class, args);
	}

}
