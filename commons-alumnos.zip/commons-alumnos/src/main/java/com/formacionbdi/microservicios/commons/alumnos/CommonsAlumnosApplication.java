package com.formacionbdi.microservicios.commons.alumnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonsAlumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonsAlumnosApplication.class, args);
	}

}
